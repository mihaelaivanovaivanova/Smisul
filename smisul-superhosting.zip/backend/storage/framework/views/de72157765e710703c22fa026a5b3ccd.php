<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="utf-8">
    <title>Поръчка <?php echo e($order->order_number); ?> е отказана</title>
</head>
<body style="font-family: -apple-system, Arial, sans-serif; color: #1a1a1a; max-width: 600px; margin: 0 auto;">
    <h1 style="font-size: 20px;">Поръчка <?php echo e($order->order_number); ?> е отказана</h1>

    <p>Здравей, <?php echo e($order->customer_first_name); ?>,</p>

    <p>Поръчка <strong><?php echo e($order->order_number); ?></strong> на стойност <?php echo e(number_format((float) $order->grand_total, 2)); ?> <?php echo e($order->currency); ?> беше отказана.</p>

    <p>Ако не си очаквал/а това или имаш въпроси, свържи се с нас.</p>
</body>
</html>
<?php /**PATH D:\Projects\Smisul\backend\resources\views/emails/orders/cancelled.blade.php ENDPATH**/ ?>
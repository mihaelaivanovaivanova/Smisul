<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="utf-8">
    <title>Фактура — <?php echo e($order->order_number); ?></title>
    <style>
        body { font-family: -apple-system, Arial, sans-serif; color: #1a1a1a; max-width: 700px; margin: 40px auto; }
        table { width: 100%; border-collapse: collapse; margin: 16px 0; }
        th, td { text-align: left; padding: 6px; border-bottom: 1px solid #eee; }
        .totals td { border: none; }
        .placeholder-notice { color: #a1a1aa; font-size: 12px; margin-top: 32px; }
    </style>
</head>
<body>
    <h1>Фактура (placeholder)</h1>
    <p>
        Поръчка: <strong><?php echo e($order->order_number); ?></strong><br>
        Дата: <?php echo e($order->created_at->format('d.m.Y')); ?>

    </p>

    <h2>Клиент</h2>
    <p>
        <?php echo e($order->customerFullName()); ?><br>
        <?php echo e($order->customer_email); ?><br>
        <?php echo e($order->customer_phone); ?>

        <?php if($order->customer_company): ?>
            <br><?php echo e($order->customer_company); ?>

            <?php if($order->customer_vat_number): ?>
                (ДДС №: <?php echo e($order->customer_vat_number); ?>)
            <?php endif; ?>
        <?php endif; ?>
    </p>

    <h2>Адрес за фактуриране</h2>
    <p>
        <?php echo e($order->billing_address_line); ?><?php echo e($order->billing_apartment ? ', '.$order->billing_apartment : ''); ?><br>
        <?php echo e($order->billing_city); ?>, <?php echo e($order->billing_postal_code); ?><br>
        <?php echo e($order->billing_country); ?>

    </p>

    <table>
        <thead>
            <tr>
                <th>Продукт</th>
                <th>SKU</th>
                <th>Количество</th>
                <th>Ед. цена</th>
                <th>Общо</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->product_name); ?><?php echo e($item->variant_name ? " ({$item->variant_name})" : ''); ?></td>
                    <td><?php echo e($item->sku); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td><?php echo e(number_format((float) $item->unit_price, 2)); ?> <?php echo e($order->currency); ?></td>
                    <td><?php echo e(number_format((float) $item->line_total, 2)); ?> <?php echo e($order->currency); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="totals">
            <tr><td colspan="4">Междинна сума</td><td><?php echo e(number_format((float) $order->subtotal, 2)); ?> <?php echo e($order->currency); ?></td></tr>
            <?php if((float) $order->discount_total > 0): ?>
                <tr><td colspan="4">Отстъпка</td><td>-<?php echo e(number_format((float) $order->discount_total, 2)); ?> <?php echo e($order->currency); ?></td></tr>
            <?php endif; ?>
            <tr><td colspan="4">Доставка (<?php echo e($order->shipping_method_label); ?>)</td><td><?php echo e(number_format((float) $order->shipping_price, 2)); ?> <?php echo e($order->currency); ?></td></tr>
            <tr><td colspan="4"><strong>Общо</strong></td><td><strong><?php echo e(number_format((float) $order->grand_total, 2)); ?> <?php echo e($order->currency); ?></strong></td></tr>
        </tfoot>
    </table>

    <p class="placeholder-notice">
        Това е временен, опростен документ и не представлява данъчна фактура. Реалното фактуриране предстои да бъде внедрено.
    </p>
</body>
</html>
<?php /**PATH D:\Projects\Smisul\backend\resources\views/invoices/order.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="utf-8">
    <title>Поръчка <?php echo e($order->order_number); ?> е изпратена</title>
</head>
<body style="font-family: -apple-system, Arial, sans-serif; color: #1a1a1a; max-width: 600px; margin: 0 auto;">
    <h1 style="font-size: 20px;">Поръчката ти е на път, <?php echo e($order->customer_first_name); ?>!</h1>

    <p>Поръчка <strong><?php echo e($order->order_number); ?></strong> беше предадена на <?php echo e($order->shipping_method_label); ?> и е на път към теб.</p>

    <p>
        Адрес за доставка:<br>
        <?php echo e($order->shipping_address_line); ?><?php echo e($order->shipping_apartment ? ', '.$order->shipping_apartment : ''); ?><br>
        <?php echo e($order->shipping_city); ?>, <?php echo e($order->shipping_postal_code); ?><br>
        <?php echo e($order->shipping_country); ?>

    </p>
</body>
</html>
<?php /**PATH D:\Projects\Smisul\backend\resources\views/emails/orders/shipped.blade.php ENDPATH**/ ?>
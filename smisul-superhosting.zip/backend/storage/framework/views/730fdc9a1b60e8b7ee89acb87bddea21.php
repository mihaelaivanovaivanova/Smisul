<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="utf-8">
    <title>Поръчка <?php echo e($order->order_number); ?> е потвърдена</title>
</head>
<body style="font-family: -apple-system, Arial, sans-serif; color: #1a1a1a; max-width: 600px; margin: 0 auto;">
    <h1 style="font-size: 20px;">Поръчката ти е потвърдена, <?php echo e($order->customer_first_name); ?>!</h1>

    <p>Плащането по поръчка <strong><?php echo e($order->order_number); ?></strong> е получено и вече подготвяме пратката ти.</p>

    <table width="100%" cellpadding="6" cellspacing="0" style="border-collapse: collapse; margin: 16px 0;">
        <thead>
            <tr style="border-bottom: 1px solid #ddd; text-align: left;">
                <th>Продукт</th>
                <th>Количество</th>
                <th>Цена</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="border-bottom: 1px solid #eee;">
                    <td><?php echo e($item->product_name); ?><?php echo e($item->variant_name ? " ({$item->variant_name})" : ''); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td><?php echo e(number_format((float) $item->line_total, 2)); ?> <?php echo e($order->currency); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <p><strong>Общо: <?php echo e(number_format((float) $order->grand_total, 2)); ?> <?php echo e($order->currency); ?></strong></p>
</body>
</html>
<?php /**PATH D:\Projects\Smisul\backend\resources\views/emails/orders/confirmed.blade.php ENDPATH**/ ?>
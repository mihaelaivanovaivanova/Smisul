<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>New order <?php echo e($order->order_number); ?></title>
</head>
<body style="font-family: -apple-system, Arial, sans-serif; color: #1a1a1a; max-width: 600px; margin: 0 auto;">
    <h1 style="font-size: 20px;">New order: <?php echo e($order->order_number); ?></h1>

    <p>
        Customer: <?php echo e($order->customerFullName()); ?> &lt;<?php echo e($order->customer_email); ?>&gt;<br>
        Phone: <?php echo e($order->customer_phone); ?><br>
        <?php if($order->customer_company): ?>
            Company: <?php echo e($order->customer_company); ?> (VAT: <?php echo e($order->customer_vat_number ?? 'n/a'); ?>)<br>
        <?php endif; ?>
        Type: <?php echo e($order->isGuestOrder() ? 'Guest checkout' : 'Registered customer'); ?>

    </p>

    <table width="100%" cellpadding="6" cellspacing="0" style="border-collapse: collapse; margin: 16px 0;">
        <thead>
            <tr style="border-bottom: 1px solid #ddd; text-align: left;">
                <th>SKU</th>
                <th>Product</th>
                <th>Qty</th>
                <th>Line total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="border-bottom: 1px solid #eee;">
                    <td><?php echo e($item->sku); ?></td>
                    <td><?php echo e($item->product_name); ?><?php echo e($item->variant_name ? " ({$item->variant_name})" : ''); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td><?php echo e(number_format((float) $item->line_total, 2)); ?> <?php echo e($order->currency); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <p><strong>Grand total: <?php echo e(number_format((float) $order->grand_total, 2)); ?> <?php echo e($order->currency); ?></strong></p>

    <p>
        Shipping: <?php echo e($order->shipping_method_label); ?><br>
        <?php echo e($order->shipping_address_line); ?><?php echo e($order->shipping_apartment ? ', '.$order->shipping_apartment : ''); ?>,
        <?php echo e($order->shipping_city); ?> <?php echo e($order->shipping_postal_code); ?>, <?php echo e($order->shipping_country); ?>

    </p>

    <?php if($order->delivery_notes): ?>
        <p>Delivery notes: <?php echo e($order->delivery_notes); ?></p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH D:\Projects\Smisul\backend\resources\views/emails/orders/admin-notification.blade.php ENDPATH**/ ?>
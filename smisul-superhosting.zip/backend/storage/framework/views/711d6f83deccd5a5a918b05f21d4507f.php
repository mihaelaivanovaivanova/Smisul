<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="utf-8">
    <title>Потвърждение на поръчка <?php echo e($order->order_number); ?></title>
</head>
<body style="font-family: -apple-system, Arial, sans-serif; color: #1a1a1a; max-width: 600px; margin: 0 auto;">
    <h1 style="font-size: 20px;">Благодарим ти за поръчката, <?php echo e($order->customer_first_name); ?>!</h1>

    <p>Поръчка <strong><?php echo e($order->order_number); ?></strong> е приета и очаква обработка.</p>

    <table width="100%" cellpadding="6" cellspacing="0" style="border-collapse: collapse; margin: 16px 0;">
        <thead>
            <tr style="border-bottom: 1px solid #ddd; text-align: left;">
                <th>Продукт</th>
                <th>Количество</th>
                <th>Цена</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="border-bottom: 1px solid #eee;">
                    <td><?php echo e($item->product_name); ?><?php echo e($item->variant_name ? " ({$item->variant_name})" : ''); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td><?php echo e(number_format((float) $item->line_total, 2)); ?> <?php echo e($order->currency); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <p>
        Междинна сума: <?php echo e(number_format((float) $order->subtotal, 2)); ?> <?php echo e($order->currency); ?><br>
        Доставка (<?php echo e($order->shipping_method_label); ?>): <?php echo e(number_format((float) $order->shipping_price, 2)); ?> <?php echo e($order->currency); ?><br>
        <strong>Общо: <?php echo e(number_format((float) $order->grand_total, 2)); ?> <?php echo e($order->currency); ?></strong>
    </p>

    <h2 style="font-size: 16px;">Адрес за доставка</h2>
    <p>
        <?php echo e($order->shipping_address_line); ?><?php echo e($order->shipping_apartment ? ', '.$order->shipping_apartment : ''); ?><br>
        <?php echo e($order->shipping_city); ?>, <?php echo e($order->shipping_postal_code); ?><br>
        <?php echo e($order->shipping_country); ?>

    </p>

    <p style="color: #666; font-size: 13px;">
        Плащането ще бъде добавено в следваща стъпка — засега поръчката е регистрирана и очаква потвърждение.
    </p>
</body>
</html>
<?php /**PATH D:\Projects\Smisul\backend\resources\views/emails/orders/confirmation.blade.php ENDPATH**/ ?>
<?php echo e($slot); ?>

<?php /**PATH D:\Projects\Smisul\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>